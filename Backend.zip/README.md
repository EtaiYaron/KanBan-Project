# Kanban
Instructions: 
* Replace "ID1_ID2_ID3" with the correct ID numbers
* Replace the "00" number at the end with your group's number


## Group members
215825639_215376518_329453732

## Group number (from Moodle)
24
